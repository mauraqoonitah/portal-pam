 </section></div>
<div class="contact-block container">
	<div class="row">
		<div class="col-xs-12">
			<?php

include($config['basepath'].'phpmailer/class.phpmailer.php');
include($config['basepath'].'phpmailer/class.smtp.php');
$mail = new PHPMailer();
$mail->isSMTP(); 
$mail->Host     = $config['host_mail']; 
$mail->Mailer   = "smtp";
$mail->SMTPAuth = true; 

$mail->Username = $config['username_mail']; 
$mail->Password = $config['password_mail'];
$mail->SMTPSecure 	= "tls";                            // Enable TLS encryption, `ssl` also accepted
$mail->Port 		= $config['port_mail'];      
$webmaster_email = $config['webemail']; 
$email =$config['webemail'];
$name = $_POST['username'];
$mail->From = $webmaster_email;
$mail->FromName = $config['from_name_mail'];
$mail->AddCC($config['cc']);
$mail->AddAddress($email,$name);
$mail->AddReplyTo($_POST['useremail'],$_POST['username']);
$mail->WordWrap = 50; 
$subject = $config['subject_mail'];

//$mail->AddAttachment("module.txt"); // attachment
//$mail->AddAttachment("new.jpg"); // attachment
$mail->IsHTML(true); 
$mail->Subject = $config['subject_mail']; 	
//$mail->Body =  "Name : ".$_POST['username'];
//$mail->Body =  "Email :".$_POST['useremail'];
//$mail->Body =  "Phone : ".$_POST['usertelp'];
$mail->Body =  $_POST['userpesan'];

$mail->AltBody = "This is the body when user views in plain text format"; 
if(!$mail->Send())
{
//echo "Mailer Error: " . $mail->ErrorInfo;
}
else
{
	echo '<div class="alert alert-info fade in">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <i class="icon-info"></i> ' . "email berhasil dikirim" . '
            </div>';


}
?>

		</div>
	</div>


		<style>
    .google-maps {
        position: relative;
        padding-bottom: 5%; // This is the aspect ratio
        height: 0;
        overflow: hidden;
    }
    .google-maps iframe {
        position: absolute;
        top: 0;
        left: 0;
        width: 100% !important;
        height: 100% !important;
    }
</style>
<h1><center><font color="#222">Kami beralamat di:</font></center></h1><br>
<div class="google-maps">
   <script src='https://maps.googleapis.com/maps/api/js?v=3.exp&key= AIzaSyCxKVhOEQMXBAbKPWzgpi_wmMOQURXa79s '></script><div style='overflow:hidden;height:400px;width:1100px;'><div id='gmap_canvas' style='height:400px;width:1100px;'></div><style>#gmap_canvas img{max-width:none!important;background:none!important}</style></div> <a href='https://www.embedmap.net/'>.</a> <script type='text/javascript' src='https://embedmaps.com/google-maps-authorization/script.js?id=6d707a170facc84cda489f5d08d6229fb888df8b'></script><script type='text/javascript'>function init_map(){var myOptions = {zoom:13,center:new google.maps.LatLng(<?php echo $config['coordinat']; ?>),mapTypeId: google.maps.MapTypeId.ROADMAP};map = new google.maps.Map(document.getElementById('gmap_canvas'), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(<?php echo $config['coordinat']; ?>)});infowindow = new google.maps.InfoWindow({content:'<strong><?php echo $config['nama_tempat']; ?></strong><br><?php echo $config['nama_jalan']; ?>'});google.maps.event.addListener(marker, 'click', function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);</script>

</div>






<div class="col-xs-12">
				<h1><center><font color="#787F81">CONTACT US</font></center></h1><br>
			<div class="contact-address">
								<div class="alignleft">
								<center>
									<img class="img-responsive" alt="MNZ LOGO" src="<?php echo $config['baseurl'];?>images/header/<?php echo $config['logoheader'];?>">
									</center>
								</div>
								<div class="contact-info">
									<h3><i class="fa fa-road"></i><font color="#787F81">addreas</font>
									<address><?php echo $config['alamat_kontak']; ?></address><br>
									<h3><i class="fa fa-phone"></i><font color="#787F81">phone number</font></h3>
									<div class="tel-box">
										
											<a href="tel:<?php echo $config['telp']; ?>" class="tel"><?php echo $config['telp']; ?></a>
										
									</div><br>
									<h3><i class="fa fa-envelope"></i><font color="#787F81">email</font></h3>
									<a href="mailto:<?php echo $config['email']; ?>"><?php echo $config['email']; ?></a>
								</div>
			</div>
		</div>





	</div>
	</div>
<br>
<br>
<br>

	 <section id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Contact Us</h2>
                    <h3 class="section-subheading text-muted"></h3>
                </div>
            </div>
           <div class="row contact-message">	
                <div class="col-lg-12">
                      <form id="emailForm" class="contact-form2" method="post" enctype="multipart/form-data" name="emailForm">
				                    <div class="usermessagea"></div>  <fieldset>
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">

                                    <input type="text" class="form-control" placeholder="Your Name *" name="username" id="name-contact-us" required data-validation-required-message="Please enter your name.">
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" placeholder="Your Email *" name="useremail" id="email-contact-us" required data-validation-required-message="Please enter your email address.">
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Your Phone *" name="usertelp" id="email-contact-us" required data-validation-required-message="Please enter your phone number.">
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>

                            <div class="col-md-9">
                                <div class="form-group">
                                    <textarea class="form-control" placeholder="Your Message *" name="userpesan" id="message-contact-us" required data-validation-required-message="Please enter a message."></textarea>
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-lg-12 text-center">
                                <div id="success"></div>
                                <input type="hidden" name="id_form" value="126" />
				                            <input type="submit" name="yit_sendmail" value="Send Message" class="btn btn-f-info" style="color:#000;" />	
				                            	
                            </div>
                        </div>
                          </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </section>





<!--

	<div class="row contact-message">			    
		<div class="col-sm-6 col-xs-12">
				<h2>Send a message</h2>
				                <form id="emailForm" class="contact-form2" method="post" enctype="multipart/form-data" name="emailForm">
				                    <div class="usermessagea"></div>
				                    <fieldset>
											<input type="text" class="form-control" name="username" id="name-contact-us"  placeholder="Nama"/>
				                            <input type="text" class="form-control"  name="useremail" id="email-contact-us"  placeholder="E-mail"/>
				                            <input type="text" class="form-control"  name="usertelp" id="email-contact-us"  placeholder="No.Telp/HP"/>			                            
				                            <textarea class="form-control" name="userpesan" id="message-contact-us" rows="8" cols="30" placeholder="Pesan"></textarea>
				                            <input type="hidden" name="id_form" value="126" />
				                            <input type="submit" name="yit_sendmail" value="Send Message" class="btn btn-f-info" style="color:#fff;" />			
				                            
				                    </fieldset>
				                </form>
							
				            <div id="comments">
				            </div>
				           
		</div>
		
	</div>
</div>-->
</div>

<section>