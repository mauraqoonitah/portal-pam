</div>
<?php
$merk=get('brand');
$size=get('ukuran');

//echo 'merk '.$merk;
//echo 'ukuran '.$size;

$order  = get('order');
$sort   = get('sort');
$kat    = get('kat');

//sort berdasarkan harga
if (strlen($merk)>0){
    switch ($merk) {
        case 'canon':
            $order = 'brand asc';
            break;
        case 'avision':
            $order = 'brand asc';
            break;

        case 'fujitsu':
            $order = 'brand asc';
            break;
        case 'kodak':
            $order = 'brand asc';
            break;
        
        case 'panasonic':
            $order = 'brand asc';
            break;
       
        default:
            $sort  = 'terbaru';
            $order = 'id desc';
            
    }
} else {
    //$order = 'id desc';
 //   $sort  = 'terbaru';
}

if (strlen($size)>0){
    switch ($size) {

        case 'a3':
            $order = 'ukuran asc';
            break;

        case 'a4':
            $order = 'ukuran asc';
            break;
       
        default:
            $sort  = 'terbaru';
            $order = 'id desc';
            
    }
} else {
    //$order = 'id desc';
    //$sort  = 'terbaru';
}


if (strlen($sort)>0){
    switch ($sort) {
         
        case 'termurah':
            $order = 'price asc';
            break;
        case 'termahal':
            $order = 'price desc';
            break;
        case 'terbaru':
            $order = 'id desc';
            break;
        case 'terlama':
            $order = 'id asc';
            break;
        default:
            $sort  = 'terbaru';
            $order = 'id desc';
             
    }
} else {
    $order = 'id desc';
   // $sort  = 'terbaru';
}


$where = '';


if (strlen($kat)>0){
    $idkat = doquery('select lft,rgt from ec_category where nama_category_alias='.q($kat));
    $rowkat = $idkat[0];
    
    $dbkat = doquery('select id from ec_category where lft between '.$rowkat['lft'].' and '.$rowkat['rgt']);
    $in = '';
    foreach($dbkat as $rowkat){
        $in .= ','.$rowkat['id'];
    }
    $in = substr($in,1);
    $where .= ' and id_category in ('.$in.')';
}


    

//$brand=' and brand="'.$merk.'"';

if (strlen($merk)>0){
$brand=' and brand="'.$merk.'"';

}else{
$brand = '';

}


if (strlen($size)>0){

$ukuran=' and ukuran="'.$size.'"';
}
else{

$ukuran = '';   
}

//hitung jumlah item
$sql_count = "select count(id) as banyak from ec_product where published=1 ".$where.$brand.$ukuran;
//echo $sql_count;
$reccount = doquery($sql_count);
$rowcount = $reccount[0]['banyak'];
//echo $rowcount;

//get page, per page tampilin 25
$perpage = 36;
if (isset($_GET['page'])){
    
    $page = get('page');
    $total_page = ceil($rowcount / $perpage);
    
    if ($page>$total_page){
        $page = $total_page;
    } else if ($page < 1 ){
        $page = 1;
    }
    $sql_limit = $perpage * ($page - 1).','.$perpage;
    
} else {
    $page = 1;
    $sql_limit = '0,'.$perpage;
}

$sql = 'select * from ec_product where published=1 '.$where.$brand.$ukuran.' order by '.$order. ' limit '.$sql_limit;
//echo $sql;
$dataproducts = doquery($sql);
$currentcount = count($dataproducts);
$path = $config['baseurl'].'themes/mnzweb/'; 

 $nama_template = '7sky';
   $template_pathelite = $config['baseurl'] . 'themes/elite/magexpress/';
?>

<script language="javascript">

    //$('.messageBox').hide();
$(function(){
    $(".filter").change(function(){
        //alert("test");
        var brand = '<?php echo $merk ?>';
        var ukuran = '<?php echo $size ?>';
        //alert(brand);
        //alert(ukuran);
        if (brand.length>0 && ukuran.length>0 ){
            brand = 'product/<?php echo $merk ?>/<?php echo $size ?>/index.html';
            }
        else if (brand.length>0){
            brand = 'product/<?php echo $merk ?>/index.html';
            } 
        else {
            brand = 'product';
        }
        
        var order = '?sort='+$('#filter').val();
        
        window.location.href="<?php echo $config['baseurl']; ?>"+brand+order; 

    });
    

    $(".filter4").change(function(){
        //alert("test");
        var brand = '<?php echo $merk ?>';
        var ukuran = '<?php echo $size ?>';
        //alert(brand);
        //alert(ukuran);
        if (brand.length>0 && ukuran.length>0 ){
            brand = 'product/<?php echo $merk ?>/<?php echo $size ?>/index.html';
            }
        else if (brand.length>0){
            brand = 'product/<?php echo $merk ?>/index.html';
            } 
        else {
            brand = 'product';
        }
        
        var order = '?sort='+$('#filter4').val();
        
        window.location.href="<?php echo $config['baseurl']; ?>"+brand+order; 

    });	

	
    $(".filter2").change(function(){
        //alert("test");
        var brand = '<?php echo $merk ?>';
        var ukuran = '<?php echo $size ?>';
        //alert(brand);
        //alert(ukuran);
        if (brand.length>0 && ukuran.length>0 ){
            brand = 'product/<?php echo $merk ?>/<?php echo $size ?>/index.html';
            }
        else if (brand.length>0){
            brand = 'product/<?php echo $merk ?>/index.html';
            } 
        else {
            brand = 'product';
        }
        
        var order = '?brand='+$('#filter2').val();
        
        window.location.href="<?php echo $config['baseurl']; ?>"+brand+order; 
        
        //var order = '?sort='+$('#filter').val();
        //if (kat.length>0){
        //  kat = 'kat-<?php echo $kat ?>';
        //} else {
        //  kat = 'modul/product/';
        //}
        //var order = '?sort='+$('#filter').val();
        
        //window.location.href="<?php echo $config['baseurl']; ?>"+kat+order; 
    });
    
})

$(function(){
    $(".filter3").change(function(){
        //alert("test");
        var brand = '<?php echo $merk ?>';
        var ukuran = '<?php echo $size ?>';
        //alert(brand);
        //alert(ukuran);
        if (brand.length>0 && ukuran.length>0 ){
            brand = 'product/<?php echo $merk ?>/<?php echo $size ?>/index.html';
            }
        else if (brand.length>0){
            brand = 'product/<?php echo $merk ?>/index.html';
            } 
        else {
            brand = 'product';
        }
        
        var order = '?ukuran='+$('#filter3').val();
        
        window.location.href="<?php echo $config['baseurl']; ?>"+brand+order; 
        
        //var order = '?sort='+$('#filter').val();
        //if (kat.length>0){
        //  kat = 'kat-<?php echo $kat ?>';
        //} else {
        //  kat = 'modul/product/';
        //}
        //var order = '?sort='+$('#filter').val();
        
        //window.location.href="<?php echo $config['baseurl']; ?>"+kat+order; 
    });
    
})

    
    $("#dialog-addtocart").dialog("open");
    
    function addToCart(id_product){
        $.ajax({
             type: "POST",
             url: "<?php echo $config['baseurl']; ?>index.php?go=jx_add_cart",
             data: "id_product=" + id_product,
             success: function(msg){
                        $('#cart').load("<?php echo $config['baseurl']; ?>index.php?go=sidebar/cart&do=show");  
                        //$('.ui-widget').html(msg);    
                        $('.messageBox').html(msg);
                        $('.messageBox').show();
                        $('.messageBox').fadeIn().delay(10000).fadeOut('slow');         
                      }
        });
    }

    function tampilkan(view) {
        
        if (view == 'list') {
            $('.product-grid').attr('class', 'product-list');
            $('.product-panel').html('Tampilan <p><span id="list" class="list_on"></span><span id="grid" onclick="tampilkan(\'grid\');"></span></p>');
        } else {
            $('.product-list').attr('class', 'product-grid');                   
            //$('.product-panel').html('');
            $('.product-panel').html('Tampilan <p><span id="list" onclick="tampilkan(\'list\');"></span><span id="grid" class="grid_on"></span></p>');
        }
        $('#loader').load('<?php echo $config['baseurl'];?>index.php?go=jx_list_grid&tipelist='+view);
    }   
</script>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">



    <title><?php echo $config['websitetitle']; ?></title>
    <?php
    $sidebar = getsidebar();
    $template_path = $config['baseurl'] . 'themes/elite/';
       $template_pathss = $config['baseurl'] .  'themes/elite/artmenu/';
    registerCSS($config['baseurl'] . 'res/ecommerce.css');
$path = $config['baseurl'].'themes/elite/mnzweb/'; 
$config['theme']='';
    $nama_template = '7sky';
        $template_path7sky = $config['baseurl'] . 'themes/'.$nama_template.'/';
        $template_pathelite = $config['baseurl'] . 'themes/elite/magexpress/';


    ?>

    <!-- Bootstrap Core CSS -->
    <link rel="shortcut icon" href="<?php echo $template_path; ?>img/favicon-cicle.png" type="image/x-icon">

    <link href="<?php echo $template_path; ?>vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

 

    <link rel="stylesheet" type="text/css" href="<?php echo $template_path; ?>slider/WOW/engine1/style.css" />

 <script src="<?php echo $template_path; ?>scanner/jquery.js"></script>        
    <link rel="stylesheet" href="<?php echo $template_path; ?>scanner/style.css" media="screen">
    <link rel="stylesheet" href="<?php echo $config['baseurl'];?>res/form.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?php echo $config['baseurl'];?>res/ecommerce.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?php echo $config['baseurl'];?>themes-ui/smoothness/jquery-ui-1.8.4.custom.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?php echo $config['baseurl'];?>res/blokpromo.css" type="text/css" media="screen" />
    <script src="<?php echo $template_path; ?>scanner/script.js"></script>

  

        
        <!-- CSSs Plugin -->
        <link rel="stylesheet" id="thickbox-css" href="<?php echo $template_path;?>7sky/css/thickbox.css" type="text/css" media="all" />
        <link rel="stylesheet" id="styles-minified-css" href="<?php echo $template_path;?>7sky/css/style-minifield.css" type="text/css" media="all" />
     
        <link rel="stylesheet" id="cache-custom-css" href="<?php echo $template_path;?>7sky/css/cache-custom.css" type="text/css" media="all" />

        
        <link rel="stylesheet" id="max-width-1024-css" href="<?php echo $template_path;?>7sky/css/max-width-1024.css" type="text/css" media="screen and (max-width: 1240px)" />
        <link rel="stylesheet" id="max-width-768-css" href="<?php echo $template_path;?>7sky/css/max-width-768.css" type="text/css" media="screen and (max-width: 987px)" />
        <link rel="stylesheet" id="max-width-480-css" href="<?php echo $template_path;?>7sky/css/max-width-480.css" type="text/css" media="screen and (max-width: 480px)" />
        <link rel="stylesheet" id="max-width-320-css" href="<?php echo $template_path;?>7sky/css/max-width-320.css" type="text/css" media="screen and (max-width: 320px)" />
        
        <!-- CSSs Plugin -->
        <link rel="stylesheet" id="thickbox-css" href="<?php echo $template_path;?>7sky/css/thickbox.css" type="text/css" media="all" />
        <link rel="stylesheet" id="styles-minified-css" href="<?php echo $template_path;?>7sky/css/style-minifield.css" type="text/css" media="all" />
     
        <link rel="stylesheet" id="cache-custom-css" href="<?php echo $template_path;?>7sky/css/cache-custom.css" type="text/css" media="all" />
        <link rel="stylesheet" id="custom-css" href="<?php echo $template_path;?>7sky/css/custom.css" type="text/css" media="all" />
     
       <link href="<?php echo $template_path; ?>vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>
        
<link rel="stylesheet" type="text/css" href="<?php echo $template_pathelite; ?>assets/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo $template_pathelite; ?>assets/css/animate.css">
<link rel="stylesheet" type="text/css" href="<?php echo $template_pathelite; ?>assets/css/slick.css">
<link rel="stylesheet" type="text/css" href="<?php echo $template_pathelite; ?>assets/css/theme.css">
<link rel="stylesheet" type="text/css" href="<?php echo $template_pathelite; ?>assets/css/style.css">

        
    <link href="<?php echo $template_path; ?>css/agency.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="<?php echo $path;?>css/page-assets.css">
            <!-- include the helping elements stylesheets of  the page  -->
            <link rel="stylesheet" type="text/css" href="<?php echo $path;?>css/helper-elements.css">
            <!-- include the site stylesheet  -->
            <link rel="stylesheet" type="text/css" href="<?php echo $path;?>style.css">
            <!-- include the site color stylesheet  -->
            <link rel="stylesheet" type="text/css" href="<?php echo $path;?>css/color/ucla-gold.css">
        <!-- JAVASCRIPTs -->
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js" integrity="sha384-0s5Pv64cNZJieYFkXYOTId2HMA2Lfb6q2nAcx2n0RTLUnCAoTTsS0nKEO27XyKcY" crossorigin="anonymous"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js" integrity="sha384-ZoaMbDF+4LeFxg6WdScQ9nnR1QC2MIRxA1O9KWEXQwns1G8UNyIEZIQidzb0T1fo" crossorigin="anonymous"></script>
    <![endif]-->
<script src="<?php echo $template_path; ?>slider/js/jssor.slider-22.2.10.min.js" type="text/javascript"></script>


</head>

    <div id="wrapper" class="section-active">
        <div class="w1">
    <!-- Navigation -->        <header id="header" class="style12 fixed-position">
                <div class="container">                 
                    <div class="row">
                        <div class="col-xs-12">
                        <nav id="nav">

                            <a id="headeer" href="#" class="nav-opener"><i class="fa fa-bars"></i></a>

                            <div class="nav-holder">
                                <center>

                                <div class="logo">
                                
                                      <img src="<?php echo $template_path; ?>img/logo-elite.png" width="150px"  height="45px"  alt="">
                                
                                </div></center>
                                <?php echo widget('artmenu_front',array('tipe'=>'mainmenu','posisi'=>'horizontal')); ?> 
                                <!--
                                <ul class="list-inline nav-top">
                                    <li class="has-mega-drop active">
                                        <a href="#" class="smoothanchor">Home</a>
                                    </li>
                                    <li class="has-drop">
                                        <a href="#about" class="smoothanchor">About</a>                                     
                                    </li>
                                    <li class="has-drop">
                                        <a href="#news" class="smoothanchor">News</a>                                       
                                    </li>
                                    <li class="has-drop">
                                        <a href="#project" class="smoothanchor">Project</a>                                     
                                    </li>
                                    <li class="has-drop">
                                        <a href="#contact" class="smoothanchor">Contact</a>                                     
                                    </li>
                                </ul>
                                -->
                            </div>
                        </nav>

                          
                        </div>
                    </div>
                </div>
            </header>
            <!-- /.navbar-collapse -->


    </nav>
            

<section class="bg-light-black">
   <br>
   <br> <br>
   <br>
        <div class="container">
            <div class="intro-text">
                <div class="col-md-5">
                   <center>
                  <h2 class="service-heading"><font color="white">
<?php echo $config['welcome_message'];?></font></h2><br><br>
                
                <center></center>
                <a href="<?php echo $sidebar['read_more'];?>" class="page-scroll btn btn-xl">READ MORE</a><br><br>
                </div></center>
                  <div class="col-md-2">
</div>
                <div class="col-md-5">
                   
                   <img src="<?php echo $template_path; ?>img/cloud-svr.png" width="400px" height="400px"   class="img-responsive"  > <br>
                </div>
                
            </div>
        </div>
   
</section>
<!-- End WOWSlider.com HEAD section -->



        <!-- /.container-fluid -->

    

 

















<div class="product" style="margin-left:10px; ">
 
 <section id="portfolio" class="bg-light-gray">
        <div class="container">
<div class="row"><
 
            <!--
       
                
                    <div class="art-content-layout-row">
                        <div class="art-layout-cell art-sidebar1"><div class="art-vmenublock clearfix">
                          
        <div class="art-vmenublockheader">
            <h3 class="t">Scanner</h3>
        </div>
        <div class="art-vmenublockcontent">
      
<?php
$merk=get('brand');

?>

<?php 

        //    echo '<ul class="art-vmenu">';
        //    echo '</ul>';
        //    echo  widget('artmenu',array('tipe'=>'scannermainmenu',
        //                               'posisi'=>'vertical')); 
    
?> 
                
             
</div>
</div>


</section>

-->
     
         <!-- Portfolio Grid Section -->
   

<div class="row">
 <div class="col-lg-12 text-center">
  <h1><font color="black"> Urut Berdasarkan:</font></h1>
 <br>


 <div class="col-md-3">
<div class="single_bottom_rightbar">
            <h2>Brand</h2>
            <div class="blog_archive wow fadeInDown">
              <form action="#">
               <select name="filter2" id="filter2" class="filter2">  
                 <option value="" <?php if ($size=='') echo ' selected="selected" '; ?>>--PILIH--</option>
              <?php  $db_brand = doquery("SELECT * from ec_brand");
                              foreach ($db_brand as $row_brand ) { ?>

 <?php $sub_brand= $row_brand['id'];

                                                  ?>

     
        <option value="<?php echo $row_brand['brand']; ?>" <?php if ($merk==$row_brand['brand']) echo ' selected="selected" '; ?>>Produk <?php echo $row_brand['brand']; ?></option>
        
<?php }  ?>        
                </select>
              </form>
            </div>
          </div> </div>



           <div class="col-md-3">
<div class="single_bottom_rightbar">
            <h2>Ukuran</h2>
            <div class="blog_archive wow fadeInDown">
              <form action="#">
                <select name="filter3" id="filter3" class="filter3">  
                 <option value="" <?php if ($size=='') echo ' selected="selected" '; ?>>--PILIH--</option>
                 <option value="a3" <?php if ($size=='a3') echo ' selected="selected" '; ?>>ukuran A3</option>
        <option value="a4" <?php if ($size=='a4') echo ' selected="selected" '; ?>>ukuran A4</option>
 
                </select>
              </form>
            </div>
          </div> </div>

           <div class="col-md-3">
<div class="single_bottom_rightbar">
            <h2>Termahal-Termurah</h2>
            <div class="blog_archive wow fadeInDown">
              <form action="#">
                <select name="filter" id="filter" class="filter">  
                  <option value="" <?php if ($size=='') echo ' selected="selected" '; ?>>--PILIH--</option>
        <option value="termurah" <?php if ($sort=='termurah') echo ' selected="selected" '; ?>>Harga Termurah-Termahal</option>
        <option value="termahal" <?php if ($sort=='termahal') echo ' selected="selected" '; ?>>Harga Termahal-Termurah</option>
                </select>
              </form>
            </div>
          </div> </div>


           <div class="col-md-3">
<div class="single_bottom_rightbar">
            <h2>Terbaru-Terlama</h2>
            <div class="blog_archive wow fadeInDown">
              <form action="#">
                 <select name="filter4" id="filter4" class="filter4">  
                   <option value="" <?php if ($size=='') echo ' selected="selected" '; ?>>--PILIH--</option>
                 <option value="terbaru" <?php if ($sort=='terbaru') echo ' selected="selected" '; ?>>Produk Terbaru-Terlama</option>
				<option value="terlama" <?php if ($sort=='terlama') echo ' selected="selected" '; ?>>Produk Terlama-Terbaru</option>

                </select>
              </form>
            </div>
          </div> </div>




</div>
</div>


  <div class="urut" style="margin-right: 0px">


        
       
        </div><br><br><br>
            <div class="row">
                <div class="col-lg-12 text-center">
                    
                   
  
                </div>
            </div>



        <div class="row">

        <?php
        foreach($dataproducts as $product) 
        {
        ?>

                <div class="col-md-3 col-sm-5 portfolio-item">
                    <a href="#portfolioModal<?php echo $product['id'];?>" class="portfolio-link" data-toggle="modal">
                        <div class="portfolio-hover">
                            <div class="portfolio-hover-content">
                                <i class="fa fa-plus fa-3x"></i>
                            </div>
                        </div>
                        <?php if($product['img_icon']==""){?>
                        <img border="20" src="<?php echo $config['baseurl']; ?>images/products/kosong.jpg"  width="200px" height="160px" alt="">
 <?php }else{?>
 <img src="<?php echo $config['baseurl']; ?>images/products/<?php echo $product['img_icon'];?>"  width="200px" height="160px" alt="">
  <?php }?>
                        
                    </a>
                    <div class="portfolio-caption">
                        <h4></h4>
                         <?php if($product['logobrand']==""){?>

                        <br>&nbsp;

 <?php }else{?>

  <?php 
        $logomerk='<img src="'.$config['baseurl'].'images/logobrand/'.$product['logobrand'].'" alt="'.$merk.'" height="20"> ';
         echo $logomerk; ?>
 <?php }?>

 <?php if($product['ukuran']==""){?>
                       <p class="text-muted">&nbsp;</p>
<?php }else{?>
                        <p class="text-muted"><?php echo $product['ukuran'];?></p>
 <?php }?>



                        <?php if($product['nama_product']==""){?>
                        <p class="text-muted">&nbsp;</p>
                      
<?php }else{?>
                        <p class="text-muted"><?php echo $product['nama_product'];?></p>
 <?php }?>
                        

                    </div>
                </div>
                
            

        


        <?php
        }
        ?>
          


        </div>
    </section>

<div style="margin-top: 10px">
<?php


// tampilin page nya
require( $config['basepath'].'main/inc/paging.class.php' ); 
$paging = new paging; 



if (strlen($sort)>0) {
$paging->assign ($config['baseurl'].str_replace('//','/', 'product/'.$merk.'/'.$size.'/index.html?sort='.$sort), $rowcount, $perpage  ); 
}

else{
$paging->assign ($config['baseurl'].str_replace('//','/', 'product/'.$merk.'/'.$size.'/index.html'), $rowcount, $perpage  );        
}

$paging->use_first_last  = true;

if ($rowcount<1)
{
echo "<div style='text-align:center; font-size:14px;'><p><br><br><br><br><br><br>"; 
echo "<div style=' font-weight:bold; background-color:#E8E8E8; padding:5px'>Belum Ada Data</div>";  
echo "<br><br><br><br><br></p></div>";  
}else {
    
echo $paging->fetch(); 
echo "<br><br>".'record: '.$currentcount.'/'.$rowcount;
}?>
</div>



<p id="loader">&nbsp;</p>
<div class="container">
<div class="art-sheet">
</div>

</div>

       

  <?php
        foreach($dataproducts as $product) 
        {?>
            <div class="portfolio-modal modal fade" id="portfolioModal<?php echo $product['id'];?>" tabindex="-1" role="dialog" aria-hidden="true">
            <br>
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-lg-offset-2">
                            <div class="modal-body">
                                <!-- Project Details Go Here -->
                                
                               <h3><font color="black"><?php echo $product['nama_product'];?><br></h3></font></h3>
<center>
                                <img class="img-responsive img-centered" src="<?php echo $config['baseurl']; ?>images/products/<?php echo $product['img_icon'];?>"  height="400px" width="320px" alt=""> <p class="item-intro text-muted"> <?php 
        $logomerk='<img src="'.$config['baseurl'].'images/logobrand/'.$product['logobrand'].'" alt="'.$merk.'" height="40"> ';
         echo $logomerk; ?></p>
</center>
                               
                                <p> <?php echo $product['short_desc'];?></p>
                               
                                <hr>
                             
                                <center><p> <?php echo $product['long_desc'];?> </p></center>
                             
                                <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i>tutup </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


       <?php }
        ?>







</div>
</div>
    <footer style="background-color: black">
        <div class="container">
            <div class="row">
               
               <div class="col-md-12">
                    <ul class="list-inline social-buttons">
                        
                        <li><a href="<?php echo $config['facebook'];?>"><i class="fa fa-facebook"></i></a>
                        </li>
                        <li><a href="<?php echo $config['telp'];?>"><i class="fa fa-phone"></i></a>
                        </li>
                         <li><a href="<?php echo $config['twitter'];?>"><i class="fa fa-twitter"></i></a>
                        </li>
                    </ul>
                </div>

                <div class="col-md-12">
                    <ul class="list-inline quicklinks">
                     
                    </ul>
                </div>
                 <div class="col-md-12">
                    <span class="copyright"> <?php echo $config['webfooter'];?></span>
                </div>
            </div>
        </div>
    </footer><div class="fa fa-chevron-up" id="gotoTop" style="display: block;"></div>
   
<script>
        // Popup Window
        var scrollTop = '';
        var newHeight = '100';

        $(window).bind('scroll', function() {
           scrollTop = $( window ).scrollTop();
           newHeight = scrollTop + 100;
        });
        
        $('.popup-trigger').click(function(e) {
         e.stopPropagation();
         if(jQuery(window).width() < 767) {
           $(this).after( $( ".popup" ) );
           $('.popup').show().addClass('popup-mobile').css('top', 0);
           $('html, body').animate({
                scrollTop: $('.popup').offset().top
            }, 500);   
         } else {
           $('.popup').removeClass('popup-mobile').css('top', newHeight).toggle();
         };
        });
        
        $('html').click(function() {
         $('.popup').hide();
        });

        $('.popup-btn-close').click(function(e){
          $('.popup').hide();
        });

        $('.popup').click(function(e){
          e.stopPropagation();
        });
        var $window = $(window);
        function checkWidth() {
            var windowsize = $window.width();
            if (windowsize < 991) {
                //if the window is greater than 440px wide then turn on jScrollPane..
                $("#headwer").removeClass("-opener");
            }
        }
        // Execute on load
        checkWidth();
    </script>

    <script type="text/javascript" src="<?php echo $template_path; ?>slider/WOW/engine1/wowslider.js"></script>
<script type="text/javascript" src="<?php echo $template_path; ?>slider/WOW/engine1/script.js"></script>

         END BG SHADOW
    
           
       <script src="<?php echo $template_pathelite; ?>assets/js/jquery.min.js"></script> 
<script src="<?php echo $template_pathelite; ?>assets/js/bootstrap.min.js"></script> 
<script src="<?php echo $template_pathelite; ?>assets/js/wow.min.js"></script> 
<script src="<?php echo $template_pathelite; ?>assets/js/slick.min.js"></script> 
<script src="<?php echo $template_pathelite; ?>assets/js/custom.js"></script>


 



    <script src="<?php echo $template_path; ?>vendor/jquery/jquery.min.js"></script>

 
    <script src="<?php echo $template_path; ?>vendor/bootstrap/js/bootstrap.min.js"></script>

  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js" integrity="sha384-mE6eXfrb8jxl0rzJDBRanYqgBxtJ6Unn4/1F7q4xRRyIw7Vdg9jP4ycT7x1iVsgb" crossorigin="anonymous"></script>

  
    <script src="<?php echo $template_path; ?>js/jqBootstrapValidation.js"></script>
    <script src="<?php echo $template_path; ?>js/contact_me.js"></script>

   
    <script src="<?php echo $template_path; ?>js/agency.min.js"></script>

</body>

</html>

