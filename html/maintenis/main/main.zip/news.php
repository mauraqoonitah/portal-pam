<?php

$id = get('id');

$dataview = doquery('select * from news where id="'.$id.'"');

if (count($dataview)<1){
    require($config['basepath'] . 'main/404.php');
} else {
    $row = $dataview[0];
    
    $url_berita                         = $config['baseurl'].$row['title_alias'];
    $url_image                          = $config['baseurl'].'images/featured/'.$row['img_ilustrasi'];
    $config['websitetitle']		= $row['title']  . ' - ' . $config['websitetitle'];
    $config['meta_title']		= $row['title'];	
    $config['meta_description']         = limit_description(strip_tags($row['intro_text']),160,' ');
    $config['meta_keyword']		= str_replace(' ',', ',$config['meta_description']);
    $config['url']                      = $url_berita;
    $config['meta_image']               = $url_image;
?><style type="text/css">
   .left    { text-align: left;}
   .right   { text-align: right;}
   .center  { text-align: center;}
   .justify { text-align: justify;}
</style>


    



 
  
  <section id="mainContent">

      <div class="col-lg-8 col-md-8">
        <div class="content_bottom_left">
          <div class="single_page_area">
            <ol class="breadcrumb">
              <li><a href="#">Home</a></li>
              <li><a href="#">Technology</a></li>
              <li class="active"><?php echo $row['title']; ?></li>
            </ol>
            <h2 class="post_titile"><?php echo $row['title']; ?></h2>
            <div class="single_page_content">
              <div class="post_commentbox"> <a href="#"><i class="fa fa-user"></i>by <?php echo $news['email']; ?></a> <span><i class="fa fa-calendar"></i><?php echo date('d',strtotime($news['created'])); ?><?php echo date('M',strtotime($news['created'])); ?><?php echo date('y',strtotime($news['created'])); ?></span> <a href="#"><?php 
												$tag_news = doquery('select * from news_tag n left join tag t on t.id=n.id_tag where n.id_news='.$id.' ');
												foreach ($tag_news as $row_news){
											?><a href="#"><i class="fa fa-tags"></i><?php echo $row_news['nama_tag']; ?></a>
										
											<?php
												}
											?></div>
              <?php  if (strlen($row['img_ilustrasi'])>0) {    ?>

              <img src="<?php echo $config['baseurl']; ?>images/news/<?php echo $row['img_ilustrasi']; ?>" alt="<?php echo $row['title']; ?>" title="<?php echo $row['title']; ?>" class="img-center"><?php } ?>
              <p class="justify"><?php echo $row['full_text']; ?> </p>
             
             
            </div>
          </div>
        </div>
       
              </div>



      <div class="col-lg-4 col-md-4">
        <div class="content_bottom_right">
          <div class="single_bottom_rightbar">
            <h2>Recent Post</h2>
           
            <ul class="small_catg popular_catg wow fadeInDown">

             <?php echo widget('newsletter'); ?>
              
            </ul>

          </div>
          
        </div>
      </div>
    </div>






							
							

						</div>
					</div>
				</div>





</div>



<?php
}

$sql_artikel_terbaru = 'select * from news where title_alias!="'.$id.'" order by created desc limit 5';
//echo $sql_artikel_terbaru;
$db_artikel_terbaru = doquery($sql_artikel_terbaru);
//$news = $db_artikel_terkait[0];
//debugvar($news);

?>

<?php
$sql_hits = 'update news set hits=hits+1 where id='.$id;
//echo $sql_hits;
doexec($sql_hits);
?>


