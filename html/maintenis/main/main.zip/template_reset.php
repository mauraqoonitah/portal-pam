<?php
unset($_SESSION['theme']);
redirect('index.php','');
?>