ini adalah contoh sidebar kiri silakan buat file baru di folder main\sidebar

