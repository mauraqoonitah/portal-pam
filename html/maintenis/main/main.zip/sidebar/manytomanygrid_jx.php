<?php
	$config['theme'] = '';
	$db_result = doquery('select * from ')
?> 