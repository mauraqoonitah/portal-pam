<?php
$banyak 			= $param['banyak'];

if ($banyak==''){
	$banyak = 2;
}

$datanews = doquery('select * from news where published="1" order by created desc limit '.$banyak);
?>

                                  
<div style="margin-left: -20px;">
    <ul>
     	<?php
		foreach($datanews as $news)
				{
			$url_berita = $config['baseurl'].'berita/'.$news['id'].'-'.$news['title_alias'].'.html';
												
		?>
			<span style="font-size: 10px"> 
			<?php echo tgl_indo($news['created']).' '.date('H:i',strtotime($news['created'])); ?> 
				</span> 
				<h2> <b><a href="<?php echo $url_berita; ?>"><?php echo $news['title']; ?></a></b></h2>
				<?php echo $news['intro_text']; ?>
                <p><br><a href="<?php echo $url_berita; ?>" class="art-button">baca lanjutannya...</a></p>
                
				
			<?php
					}
			?>	
	</ul>
	<div style="margin-left: 25px;">
	<a href="<?php echo $config['baseurl'].'modul/news-all'; ?>" class="art-button">Arsip Berita Selengkapnya</a>
	</div>
</div>
<hr style=" border: 0; height: 1px; background: #fdbf4d;">
                                    

								



