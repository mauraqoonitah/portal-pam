
<div class="portlet-content">
	<ul class="tabs">		
		<?php
			foreach($param as $link){
				echo '		<li>'.$link.'</li>';
			}
		?>
	</ul>
</div>


