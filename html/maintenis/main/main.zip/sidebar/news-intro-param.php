<?php

$param = array(	'banyak'=>'Banyak berita',
				
);

?>