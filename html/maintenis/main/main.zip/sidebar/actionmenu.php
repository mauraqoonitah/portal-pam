
<div class="portlet-content">
	<ul class="tabs">		
		<?php
			foreach($param as $judul => $link){
				echo '		<li><a href="'.$link.'">'.$judul.'</a></li>';
			}
		?>
	</ul>
</div>


