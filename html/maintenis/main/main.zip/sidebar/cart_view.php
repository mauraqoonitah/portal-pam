<?php
	$config['theme'] = '';
	
	/*
	$id_product  = post('id_product');
	$qty		 = post('qty');
	$resultcart =mysql_query("INSERT INTO ec_cart (id_user, id_product, qty) VALUES('$_SESSION[userid]','$id_product','$qty') ON DUPLICATE KEY UPDATE qty='$qty'");
	*/
?>