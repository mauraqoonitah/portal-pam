<?php

$param = array(	'banyak'=>'Banyak berita',
				'hari'	=>'Dalam berapa hari terakhir',
);

?>