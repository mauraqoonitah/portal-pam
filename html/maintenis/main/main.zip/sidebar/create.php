<h2 class="art-postheader">Tambah Data Baru</h2>

<?php
    
	include("main/".$module."/form.php");
	
?>
