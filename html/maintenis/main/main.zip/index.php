<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo $config['webname']; ?></title>
    <?php
    $template_path = $config['baseurl'] . 'themes/elite/';
      
    registerCSS($config['baseurl'] . 'res/ecommerce.css');
    $config['theme']="";
    
     $template_pathelite = $config['baseurl'] . 'themes/elite/magexpress/';

$path = $config['baseurl'].'themes/elite/mnzweb/'; 


 
    ?>
    <!-- Bootstrap Core CSS -->
    <link rel="shortcut icon" href="<?php echo $template_path; ?>img/favicon-cicle.png" type="image/x-icon">

    <link href="<?php echo $template_path; ?>vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <link href="<?php echo $template_path; ?>vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

 
 <script src="<?php echo $template_path; ?>scanner/jquery.js"></script>        
    <link rel="stylesheet" href="<?php echo $template_path; ?>scanner/style.css" media="screen">
   
    <link rel="stylesheet" href="<?php echo $config['baseurl'];?>res/blokpromo.css" type="text/css" media="screen" />
    <script src="<?php echo $template_path; ?>scanner/script.js"></script>

        
        <!-- CSSs Plugin -->
        <link rel="stylesheet" id="thickbox-css" href="<?php echo $template_path;?>7sky/css/thickbox.css" type="text/css" media="all" />
        <link rel="stylesheet" id="styles-minified-css" href="<?php echo $template_path;?>7sky/css/style-minifield.css" type="text/css" media="all" />
     
        <link rel="stylesheet" id="cache-custom-css" href="<?php echo $template_path;?>7sky/css/cache-custom.css" type="text/css" media="all" />

        
        <link rel="stylesheet" id="max-width-1024-css" href="<?php echo $template_path;?>7sky/css/max-width-1024.css" type="text/css" media="screen and (max-width: 1240px)" />
        <link rel="stylesheet" id="max-width-768-css" href="<?php echo $template_path;?>7sky/css/max-width-768.css" type="text/css" media="screen and (max-width: 987px)" />
        <link rel="stylesheet" id="max-width-480-css" href="<?php echo $template_path;?>7sky/css/max-width-480.css" type="text/css" media="screen and (max-width: 480px)" />
        <link rel="stylesheet" id="max-width-320-css" href="<?php echo $template_path;?>7sky/css/max-width-320.css" type="text/css" media="screen and (max-width: 320px)" />



    <link href="<?php echo $template_path; ?>vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>


    <!-- Theme CSS -->
    <link href="<?php echo $template_path; ?>css/agency.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="<?php echo $path;?>css/page-assets.css">
            <!-- include the helping elements stylesheets of  the page  -->
            <link rel="stylesheet" type="text/css" href="<?php echo $path;?>css/helper-elements.css">
            <!-- include the site stylesheet  -->
            <link rel="stylesheet" type="text/css" href="<?php echo $path;?>style.css">
            <!-- include the site color stylesheet  -->
            <link rel="stylesheet" type="text/css" href="<?php echo $path;?>css/color/ucla-gold.css">


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js" integrity="sha384-0s5Pv64cNZJieYFkXYOTId2HMA2Lfb6q2nAcx2n0RTLUnCAoTTsS0nKEO27XyKcY" crossorigin="anonymous"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js" integrity="sha384-ZoaMbDF+4LeFxg6WdScQ9nnR1QC2MIRxA1O9KWEXQwns1G8UNyIEZIQidzb0T1fo" crossorigin="anonymous"></script>
    <![endif]-->
<script src="<?php echo $template_path; ?>slider/js/jssor.slider-22.2.10.min.js" type="text/javascript"></script>


</head>
 <header id="header" class="style12 fixed-position">
                <div class="container">                 
                    <div class="row">
                        <div class="col-xs-12">
                        <nav id="nav">
                            <a href="#" class="nav-opener"><i class="fa fa-bars"></i></a>
                            <div class="nav-holder">
                                <div class="logo">
                                      <img src="<?php echo $template_path; ?>img/logo-elite.png" width="150px" height="45px"  alt="">
                                </div>
                                <?php echo widget('artmenu_front',array('tipe'=>'mainmenu','posisi'=>'horizontal')); ?> 
                                <!--
                                <ul class="list-inline nav-top">
                                    <li class="has-mega-drop active">
                                        <a href="#" class="smoothanchor">Home</a>
                                    </li>
                                    <li class="has-drop">
                                        <a href="#about" class="smoothanchor">About</a>                                     
                                    </li>
                                    <li class="has-drop">
                                        <a href="#news" class="smoothanchor">News</a>                                       
                                    </li>
                                    <li class="has-drop">
                                        <a href="#project" class="smoothanchor">Project</a>                                     
                                    </li>
                                    <li class="has-drop">
                                        <a href="#contact" class="smoothanchor">Contact</a>                                     
                                    </li>
                                </ul>
                                -->
                            </div>
                        </nav>

                          
                        </div>
                    </div>
                </div>
            </header>
            <!-- /.navbar-collapse --></section>
   <section class="bg-light-black">
   <br>
   <br>
   <br>
   <br>
   <br>
        <div class="container">
            <div class="intro-text">
                <div class="col-md-5">
                   <center>
                    <h3 class="service-heading"><font color="white">
<?php echo $config['welcome_message'];?></font></h3><br><br>
                
                <center></center>
                <a href="index.php" class="page-scroll btn btn-xl">READ MORE</a><br><br>
                </div></center>
                  <div class="col-md-2">
</div>
                <div class="col-md-5">
                   
                   <img src="<?php echo $template_path; ?>img/cloud-svr.png" width="400px" height="400px"   class="img-responsive"  > <br>
                </div>
                
            </div>
        </div>
   <br><br>
   <br>
   <br>
</section>


<?php
echo widget('slideruniversal7sky');
?> 








    

  

    <!-- Services Section -->
    <section id="services"  class="bg-light-servies">
        <br>
        <br>
    <br>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h1 class="section-heading"><?php echo $sidebar['judul_why_elite'];?></h1>
                    <h3 class="section-subheading text-muted"></h3>
                </div>
            </div>
            <div class="row text-center">
                <div class="col-md-4">
                    <span class="fa-stack fa-2x">
                        
                        
                    </span>
                    <h2 class="service-heading" style="color: #343434;">EFFICIENT</h2>
                    <p class="text-muted"><?php echo $sidebar['why_elite_efficient'];?></p>
                </div>
                <div class="col-md-4">
                    <span class="fa-stack fa-2x">
                     
                       
                    </span>
                    <h2 class="service-heading" style="color: #343434;">SECURE</h2>
                    <p class="text-muted"><?php echo $sidebar['why_elite_secure'];?></p>
                </div>
                <div class="col-md-4">
                    <span class="fa-stack fa-2x">
                      
                      
                    </span>
                    <h2 class="service-heading" style="color: #343434;">FAST</h2>
                    <p class="text-muted"><?php echo $sidebar['why_elite_fast'];?></p>
                </div>
            </div>
        </div>
        <br>
        <br>
        <br>
        <br>
    </section>

   

   <footer style="background-color: black">
        <div class="container">
            <div class="row">
               
                <div class="col-md-12">
                    <ul class="list-inline social-buttons">
                        
                        <li><a href="<?php echo $config['facebook'];?>"><i class="fa fa-facebook"></i></a>
                        </li>
                        <li><a href="<?php echo $config['telp'];?>"><i class="fa fa-phone"></i></a>
                        </li>
                         <li><a href="<?php echo $config['twitter'];?>"><i class="fa fa-twitter"></i></a>
                        </li>
                    </ul>
                </div>

                <div class="col-md-12">
                    <ul class="list-inline quicklinks">
                     
                    </ul>
                </div>
                 <div class="col-md-12">
                    <span class="copyright"> <?php echo $config['webfooter'];?></span>
                </div>
            </div>
        </div>
    </footer>
   <!-- END BG SHADOW -->
   

</body>

</html><div class="fa fa-chevron-up" id="gotoTop" style="display: block;"></div>
    <script type="text/javascript" src="<?php echo $path;?>js/jquery-1.11.3.min.js"></script>
    <!-- include bootstrap JavaScript -->
    <script type="text/javascript" src="<?php echo $path;?>js/bootstrap.min.js"></script>
    <!-- include custom JavaScript -->
    <script type="text/javascript" src="<?php echo $path;?>js/jquery.main.js"></script>
    <!-- include plugins JavaScript -->
    <script type="text/javascript" src="<?php echo $path;?>js/plugins.js"></script>
<script type="text/javascript">

   // Popup Window
        var scrollTop = '';
        var newHeight = '100';

        $(window).bind('scroll', function() {
           scrollTop = $( window ).scrollTop();
           newHeight = scrollTop + 100;
        });
        
        $('.popup-trigger').click(function(e) {
         e.stopPropagation();
         if(jQuery(window).width() < 767) {
           $(this).after( $( ".popup" ) );
           $('.popup').show().addClass('popup-mobile').css('top', 0);
           $('html, body').animate({
                scrollTop: $('.popup').offset().top
            }, 500);   
         } else {
           $('.popup').removeClass('popup-mobile').css('top', newHeight).toggle();
         };
        });
        
        $('html').click(function() {
         $('.popup').hide();
        });

        $('.popup-btn-close').click(function(e){
          $('.popup').hide();
        });

        $('.popup').click(function(e){
          e.stopPropagation();
        });
        var $window = $(window);
        function checkWidth() {
            var windowsize = $window.width();
            if (windowsize < 991) {
                //if the window is greater than 440px wide then turn on jScrollPane..
                $("#header").removeClass("style12 fixed-position");
            }
        }
        // Execute on load
        checkWidth();
</script>
      