<?php 
		
$webname="Elite Digital Solusindo";
$websitetitle="Elite Digital Solusindo";
$tagline_header="Elite Digital Solusindo";
$welcome_message="Elites Digital Solutions provides world-class digital archiving and cloud infrastructure solutions for small, medium, and large Indonesian organizations.";
$logoheader="7sky-kotak1.png";
$fotoheader="7sky-kotak1.png";
$host_mail="ssl://smtp.gmail.com";
$port_mail="";
$username_mail="";
$password_mail="";
$webemail="";
$cc="";
$alamat_kontak="Jl. Gajah Plaza No 194-195 Jakarta Barat";
$telp="0812.8851.2222";
$facebook="https://www.facebook.com/7sky.studio";
$twitter="https://twitter.com/7sky_studio";
$meta_title="Elite Digital Solusindo";
$meta_description="Elite Digital Solusindo";
$meta_keyword="Elite Digital Solusindo";
$webfooter="2017. See Terms of Use for more information";
$coordinat="-6.146546,106.81571859999997";
$nama_tempat="Elite Digital Solusindo";
$nama_jalan="Jl. Gajah Plaza No 194-195 Jakarta Barat";
$from_name_mail="Elite Web Admin";
$subject_mail="Web contact use";
$smptsecure_mail="tls";
 
		
?>