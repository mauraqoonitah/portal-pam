<?php 

global $breadcrumb;

$breadcrumb = array('Page Not Found'=>'');
?>

<section id="content">    
    <div class="container">
        <div class="row">
            <div class="col-md-12">        				        				
                We are sorry, the page you requested cannot be found.
            </div><!-- End .col-md-12 -->
        </div><!-- End .row -->
    </div><!-- End .container -->
        
</section><!-- End #content -->
